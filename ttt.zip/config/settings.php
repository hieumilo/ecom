<?php
return [
    'path_image' => ENV('IMAGE_URL'),
    'path_upload' => ENV('PATH_UPLOAD'),
    'paginate' => 6,
    'home_product' => 8,
    'search_paginate' => 8,
];
