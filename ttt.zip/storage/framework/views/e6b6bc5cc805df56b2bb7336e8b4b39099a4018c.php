<?php $__env->startComponent('mail::message'); ?>
# Order

<?php $__env->startComponent('mail::table'); ?>
|       |                           |                |                                              |
|:------|:------------------------- |:-------------- |:-------------------------------------------- |
| Name  | <?php echo $content['name']; ?>  |                |                                              |
| Email | <?php echo $content['email']; ?> | Address        | <?php echo $content['address']; ?>                  |
| Phone | <?php echo $content['phone']; ?> | Total price    | <?php echo number_format($content['price']); ?>     |
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::table'); ?>
| Name                  | Price                                 | Quantity                  | Value        |
|:--------------------- | -------------------------------------:| -------------------------:| ------------:|
<?php $__currentLoopData = $content['order_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
| <?php echo $item['name']; ?> | <?php echo number_format($item['price']); ?> | <?php echo $item['quantity']; ?> | <?php echo number_format($item['price'] * $item['quantity']); ?> |
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo $content['name']; ?>

<?php echo $__env->renderComponent(); ?>
