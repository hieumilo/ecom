<table border="0" width="100%">
    <tbody>
        <tr>
            <td align="center" colspan="2"><h1>Order</h1></td>
        </tr>
        <tr>
            <td width="50%">name: <?php echo $name; ?></td>
            <td width="50%">email: <?php echo $email; ?></td>
        </tr>
        <tr>
            <td width="50%">address: <?php echo $address; ?></td>
            <td width="50%">total price: <?php echo number_format($price); ?></td>
        </tr>
        <tr>
            <td colspan="2">
                <table border="0" width="100%">
                    <thead>
                        <tr align="left">
                            <th>name</th>
                            <th>price</th>
                            <th>quantity</th>
                            <th>value</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo $value['name']; ?></td>
                            <td><?php echo number_format($value['price']); ?></td>
                            <td><?php echo $value['quantity']; ?></td>
                            <td><?php echo number_format($value['price'] * $value['quantity']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
