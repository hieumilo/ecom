<!DOCTYPE html>
<html lang="en" ng-app="App">
<head>
    <meta charset="UTF-8">
    <title ng-bind="$state.current.data.pageTitle"></title>
    <!-- Bootstrap v3.3.7 -->
    <?php echo e(Html::style('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css')); ?>

    <!-- Font Awesome -->
    <?php echo e(Html::style('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css')); ?>

    <!-- Ionicons -->
    <?php echo e(Html::style('https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css')); ?>

    <!-- bootstrap-social -->
    <?php echo e(Html::style('https://cdnjs.cloudflare.com/ajax/libs/bootstrap-social/5.1.1/bootstrap-social.min.css')); ?>

    <!-- sweetalert -->
    <?php echo e(Html::style('node_modules/sweetalert/dist/sweetalert.css')); ?>

</head>
<body ng-class="$state.current.data.bodyClass">

    <div ui-view="layout"></div>

    <!-- jquery v3.2.1 -->
    <?php echo e(Html::script('https://code.jquery.com/jquery-3.2.1.min.js')); ?>

    <!-- Bootstrap v3.3.7 -->
    <?php echo e(Html::script('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js')); ?>

    <!-- jquery-easing v1.4.1 -->
    <?php echo e(Html::script('https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js')); ?>


    <?php echo e(Html::script('node_modules/datatables/media/js/jquery.dataTables.min.js')); ?>

    
    <?php echo e(Html::script('node_modules/angular/angular.js')); ?>

    <!-- angular ui-router -->
    <?php echo e(Html::script('node_modules/angular-ui-router/release/angular-ui-router.js')); ?>

    <!-- satellizer -->
    <?php echo e(Html::script('node_modules/satellizer/dist/satellizer.js')); ?>

    <!-- angular css -->
    <?php echo e(Html::script('node_modules/angular-css/angular-css.min.js')); ?>

    <!-- angular file upload -->
    <?php echo e(Html::script('node_modules/angular-file-upload/dist/angular-file-upload.min.js')); ?>

    <!-- angular translate -->
    <?php echo e(Html::script('node_modules/angular-translate/dist/angular-translate.min.js')); ?>

    <!-- dataTables.bootstrap -->
    <?php echo e(Html::script('node_modules/angular-datatables/dist/plugins/bootstrap/angular-datatables.bootstrap.min.js')); ?>

    <!-- angular-datatables -->
    <?php echo e(Html::script('node_modules/angular-datatables/dist/angular-datatables.min.js')); ?>

    <!-- angular-loading-bar -->
    <?php echo e(Html::script('node_modules/angular-loading-bar/build/loading-bar.min.js')); ?>

    <!-- chart -->
    <?php echo e(Html::script('node_modules/chart.js/dist/Chart.min.js')); ?>

    <!-- angular-chart -->
    <?php echo e(Html::script('node_modules/angular-chart.js/dist/angular-chart.min.js')); ?>

    <!-- angular-cookies -->
    <?php echo e(Html::script('node_modules/angular-cookies/angular-cookies.js')); ?>

    <!-- jquery flexslider -->
    <?php echo e(Html::script('node_modules/flexslider/jquery.flexslider.js')); ?>

    <!-- angular-flexslider -->
    <?php echo e(Html::script('node_modules/angular-flexslider/angular-flexslider.js')); ?>

    <!-- ng-timeago -->
    <?php echo e(Html::script('bower_components/ng-timeago/ngtimeago.js')); ?>

    <!-- sweetalert -->
    <?php echo e(Html::script('node_modules/sweetalert/dist/sweetalert.min.js')); ?>

    <!-- sweetalert -->
    <?php echo e(Html::script('node_modules/angular-toastr/dist/angular-toastr.tpls.js')); ?>

    <!-- admin script -->
    <?php echo e(Html::script('resources/assets/angularjs/app/admin/js/app.min.js')); ?>

    <!-- app script -->
    <!-- config -->
    <?php echo e(Html::script('resources/assets/angularjs/config/routes.config.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/config/satellizer.config.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/lang/en.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/config/translate.config.js')); ?>

    <!-- service -->
    <?php echo e(Html::script('resources/assets/angularjs/services/auth.service.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/services/API.service.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/services/cart.service.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/services/recently.service.js')); ?>

    <!-- directive -->
    <?php echo e(Html::script('resources/assets/angularjs/directives/ng-thum.directive.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/directives/like-share.directive.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/directives/comment-fb.directive.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/directives/star-rating.directive.js')); ?>

    <!-- module -->
    <?php echo e(Html::script('resources/assets/angularjs/app.module.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app.constant.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app.run.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app.config.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app.service.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app.directive.js')); ?>

    <!-- home -->
    <?php echo e(Html::script('resources/assets/angularjs/app/home/pages/header/header.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/home/components/homepage/homepage.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/home/components/search/search.component.js')); ?>

    <!-- auth -->
    <?php echo e(Html::script('resources/assets/angularjs/app/auth/login/login.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/auth/logout/logout.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/auth/signup/singup.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/auth/profile/profile.component.js')); ?>

    
    <?php echo e(Html::script('resources/assets/angularjs/app/home/components/product-list/product-list.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/home/components/product-detail/product-detail.component.js')); ?>

    <!-- recently -->
    <?php echo e(Html::script('resources/assets/angularjs/app/home/components/recently/recently.component.js')); ?>

    <!-- suggest -->
    <?php echo e(Html::script('resources/assets/angularjs/app/home/components/suggest/suggest.component.js')); ?>

    <!-- cart -->
    <?php echo e(Html::script('resources/assets/angularjs/app/home/components/cart/cart.component.js')); ?>

    <!-- admin -->
    <?php echo e(Html::script('resources/assets/angularjs/app/admin/pages/header/header.js')); ?>

    <!-- dashboard -->
    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/dashboard/dashboard.component.js')); ?>

    <!-- user -->
    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/user-list/user-list.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/user-edit/user-edit.component.js')); ?>

    <!-- category -->
    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/category-list/category-list.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/category-create/category-create.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/category-edit/category-edit.component.js')); ?>

    <!-- product -->
    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/product-list/product-list.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/product-edit/product-edit.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/product-create/product-create.component.js')); ?>

    <!-- suggest -->
    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/suggest-list/suggest-list.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/suggest-edit/suggest-edit.component.js')); ?>

    <!-- order -->
    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/order-list/order-list.component.js')); ?>

    <?php echo e(Html::script('resources/assets/angularjs/app/admin/components/order-edit/order-edit.component.js')); ?>

    
</body>
</html>
