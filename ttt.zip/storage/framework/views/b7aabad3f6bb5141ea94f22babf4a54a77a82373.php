<!DOCTYPE html>
<html lang="en" ng-app="App">
<head>
    <meta charset="UTF-8">
    <title ng-bind="$state.current.data.pageTitle"></title>
    <!-- Bootstrap v3.3.7 -->
    <?php echo e(Html::style('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css')); ?>

    <!-- Font Awesome -->
    <?php echo e(Html::style('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css')); ?>

    <!-- Ionicons -->
    <?php echo e(Html::style('https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css')); ?>

    <!-- bootstrap-social -->
    <?php echo e(Html::style('https://cdnjs.cloudflare.com/ajax/libs/bootstrap-social/5.1.1/bootstrap-social.min.css')); ?>

</head>
<body ng-class="$state.current.data.bodyClass">
    <div ui-view="layout"></div>

    <!-- jquery v3.2.1 -->
    <?php echo e(Html::script('https://code.jquery.com/jquery-3.2.1.min.js')); ?>

    <!-- Bootstrap v3.3.7 -->
    <?php echo e(Html::script('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js')); ?>

    <!-- jquery-easing v1.4.1 -->
    <?php echo e(Html::script('https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js')); ?>

    <!-- jquery.dataTables -->
    <?php echo e(Html::script('node_modules/datatables/media/js/jquery.dataTables.min.js)); ?>

    
    <?php echo e(Html::script('node_modules/angular/angular.js')); ?>

    <!-- angular ui-router -->
    <?php echo e(Html::script('node_modules/angular-ui-router/release/angular-ui-router.js')); ?>

    <!-- satellizer -->
    <?php echo e(Html::script('node_modules/satellizer/dist/satellizer.js')); ?>

    <!-- angular css -->
    <?php echo e(Html::script('node_modules/angular-css/angular-css.min.js')); ?>

    <!-- angular file upload -->
    <?php echo e(Html::script('node_modules/angular-file-upload/dist/angular-file-upload.min.js')); ?>

    <!-- angular translate -->
    <?php echo e(Html::script('node_modules/angular-translate/dist/angular-translate.min.js')); ?>

    <!-- angular-datatables -->
    <?php echo e(Html::script('node_modules/angular-datatables/dist/angular-datatables.min.js')); ?>

    <!-- dataTables.bootstrap -->
    <?php echo e(Html::script('node_modules/angular-datatables/dist/plugins/bootstrap/angular-datatables.bootstrap.min.js')); ?>

    <!-- admin script -->
    <?php echo e(Html::script('resources/assets/angularjs/app/admin/js/app.min.js')); ?>

    <!-- app script -->
    <?php echo e(Html::script('public/js/app.js')); ?>

    
</body>
</html>
