App
.config(RoutesConfig)
.config(SatellizerConfig)
.config(TranslateConfig);
