App
.directive('ngThumb', ngThumb)
.directive('fbLike', fbLike)
.directive('dynFbCommentBox', dynFbCommentBox)
.directive('starRating', starRating);
