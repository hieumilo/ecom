App
.constant('API_URL', 'http://api.ecommerce.com/');
